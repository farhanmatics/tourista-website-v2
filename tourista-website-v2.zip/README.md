![alt text](image.png)

# Tourista Website template

No, it's not rocket science, we just make the process easy and efficient to faster navigate through the requirements, eligibility checklists, visa fee payments and needful documentations. All these micro-managing capabilities blended with technology provides a faster visa approval ratio

## Sandbox used:

- Tailwind
- Express
- ejs Template
- sequelize

## How does this work?

We run `yarn start` to start an HTTP server that runs on http://localhost:8080. You can open new or existing devtools with the + button next to the devtool tabs.

## Resources

- [CodeSandbox — Docs](https://codesandbox.io/docs)
- [CodeSandbox — Discord](https://discord.gg/Ggarp3pX5H)
